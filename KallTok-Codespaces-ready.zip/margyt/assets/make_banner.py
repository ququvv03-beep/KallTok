#!/usr/bin/env python3
"""Render assets/banner.png.

Same layout and palette as the Margy banner: mint field, white glyph on the
left inside a faint rounded outline, wordmark and subtitle on the right.
The glyph is a beamed note rather than a paper plane -- same family, different
app.
"""

import pathlib

from PIL import Image, ImageDraw, ImageFont

HERE = pathlib.Path(__file__).parent

W, H = 900, 260
MINT = (0x10, 0x18, 0x27)
INK = (0xEA, 0xF2, 0xFF)
INK_SOFT = (0x4D, 0xE1, 0xD2)
WHITE = (255, 255, 255)

BOLD = "/usr/share/fonts/noto/NotoSans-Bold.ttf"
REGULAR = "/usr/share/fonts/noto/NotoSans-Regular.ttf"

WORDMARK = "KallTok"
SUBTITLE = "independent MargyT fork · @imyapolzz"


def note(draw, cx, cy, scale):
    """A bold K monogram, matching the adaptive launcher icon."""
    font = ImageFont.truetype(BOLD, int(112 * scale))
    box = draw.textbbox((0, 0), "K", font=font)
    draw.text((cx - (box[2]-box[0])/2 - box[0], cy - (box[3]-box[1])/2 - box[1]),
              "K", font=font, fill=WHITE)


def main():
    im = Image.new("RGB", (W, H), MINT)
    d = ImageDraw.Draw(im)

    # faint rounded outline around the glyph, as on the Margy banner
    d.rounded_rectangle(
        [65, 32, 250, 217], radius=58, outline=(0x9E, 0xD8, 0xBC), width=2
    )
    note(d, 157, 124, 0.95)

    wordmark = ImageFont.truetype(BOLD, 82)
    subtitle = ImageFont.truetype(REGULAR, 30)

    d.text((285, 74), WORDMARK, font=wordmark, fill=INK)
    d.text((288, 168), SUBTITLE, font=subtitle, fill=INK_SOFT)

    out = HERE / "banner.png"
    im.save(out)
    print("wrote", out, im.size)


if __name__ == "__main__":
    main()
