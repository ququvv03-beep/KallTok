#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
APK="${1:-tiktok.apk}"
if [[ ! -f "$APK" ]]; then
  echo "TikTok APK not found: $APK"
  echo "Upload a legitimate universal TikTok APK (APK, not XAPK/APKM/APKS/BUNDLE) as tiktok.apk, then run:"
  echo "  ./build-kalltok.sh tiktok.apk"
  exit 2
fi
java -version
python3 --version
./build.sh "$APK" -o build/KallTok.apk
printf '\nBuild finished: %s/build/KallTok.apk\n' "$PWD"
