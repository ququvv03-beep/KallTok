# KallTok branding and attribution

KallTok is an independent modification of MargyT maintained by `@imyapolzz`.
It is not created, affiliated with, or endorsed by the original MargyT author.

## What this fork changes

- App label and settings entry: `KallTok`.
- Launcher artwork: dark navy background and turquoise `K` monogram.
- Project banner and README branding.
- Settings footer identifies `@imyapolzz` and the upstream MargyT project.
- The Thanks section keeps the original `@narezany` author row and its Telegram/TikTok links in place, then identifies the KallTok fork maintainer beside it.
- The upstream update feed is disabled. KallTok must publish and configure its own update feed before updates are enabled.

## What remains upstream

Internal Java package names, storage keys, plugin formats, source attribution, upstream documentation links, and the original author's support information are retained where changing them would break compatibility or violate the upstream additional terms.

This fork is distributed under GPL-3.0 with the same additional terms in `ADDITIONAL-TERMS.md`. The complete corresponding source must remain available when distributing modified binaries.

The `@imyapolzz` mark currently identifies the KallTok build inside its settings and project artwork. It is **not** stamped onto videos or photos made by other people.
