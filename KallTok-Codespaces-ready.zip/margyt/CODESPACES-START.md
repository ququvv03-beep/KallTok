# KallTok — shortest build path (GitHub Codespaces)

This repository is prepared for GitHub Codespaces. The dev container installs Python 3 and JDK 17 automatically.

## One-time setup

1. Put this project in a GitHub repository you control (upload `KallTok-source.zip`, extract it, and commit the `margyt/` project contents).
2. Open the repository on GitHub, choose **Code → Codespaces → Create codespace on main**.
3. Wait for the environment to finish creating.

## Build

The original TikTok APK is not included. Obtain a legitimate **universal APK** from an official/authorized source; it must be an APK, not XAPK/APKM/APKS or an app bundle. Do not share your account credentials or install packages from untrusted mirrors.

Upload the APK into the repository root in Codespaces and name it `tiktok.apk`. In the terminal run:

```bash
./build-kalltok.sh tiktok.apk
```

If successful, the output is `build/KallTok.apk`.

## Notes

- A modified TikTok client is unofficial and may stop working after TikTok updates.
- Installing it may require uninstalling the official app because the package name is retained. This can affect local app data; make sure anything important is backed up first.
- Test without your primary account. Never enter passwords into third-party build scripts or upload signing keys.
- Keep `LICENSE`, `ADDITIONAL-TERMS.md`, and upstream attribution intact when sharing the fork.
- This setup does not bypass TikTok login, server-side restrictions, or account security.
